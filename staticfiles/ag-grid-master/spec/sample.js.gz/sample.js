
var agGrid = require('../docs/dist/ag-grid.js');

describe('describe func', function() {

    it('true is true', function() {
        expect(true).toEqual(true);
    });

});
